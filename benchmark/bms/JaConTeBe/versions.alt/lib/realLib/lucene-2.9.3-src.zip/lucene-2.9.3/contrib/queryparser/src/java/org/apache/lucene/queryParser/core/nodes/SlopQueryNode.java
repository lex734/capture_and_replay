package org.apache.lucene.queryParser.core.nodes;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.messages.MessageImpl;
import org.apache.lucene.queryParser.core.QueryNodeError;
import org.apache.lucene.queryParser.core.messages.QueryParserMessages;
import org.apache.lucene.queryParser.core.parser.EscapeQuerySyntax;

/**
 * A {@link SlopQueryNode} represents phrase query with a slop.
 * 
 * From Lucene FAQ: Is there a way to use a proximity operator (like near or
 * within) with Lucene? There is a variable called slop that allows you to
 * perform NEAR/WITHIN-like queries. By default, slop is set to 0 so that only
 * exact phrases will match. When using TextParser you can use this syntax to
 * specify the slop: "doug cutting"~2 will find documents that contain
 * "doug cutting" as well as ones that contain "cutting doug".
 */
public class SlopQueryNode extends QueryNodeImpl implements FieldableNode {

  private static final long serialVersionUID = 0L;

  private int value = 0;

  /**
   * @param query
   *          - QueryNode Tree with the phrase
   * @param value
   *          - slop value
   */
  public SlopQueryNode(QueryNode query, int value) {
    if (query == null) {
      throw new QueryNodeError(new MessageImpl(
          QueryParserMessages.NODE_ACTION_NOT_SUPPORTED, new Object[]{"query", "null"}));
    }

    this.value = value;
    setLeaf(false);
    allocate();
    add(query);
  }

  public QueryNode getChild() {
    return getChildren().get(0);
  }

  public int getValue() {
    return this.value;
  }

  private CharSequence getValueString() {
    Float f = new Float(this.value);
    if (f == f.longValue())
      return "" + f.longValue();
    else
      return "" + f;

  }

  public String toString() {
    return "<slop value='" + getValueString() + "'>" + "\n"
        + getChild().toString() + "\n</slop>";
  }

  public CharSequence toQueryString(EscapeQuerySyntax escapeSyntaxParser) {
    if (getChild() == null)
      return "";
    return getChild().toQueryString(escapeSyntaxParser) + "~"
        + getValueString();
  }

  public QueryNode cloneTree() throws CloneNotSupportedException {
    SlopQueryNode clone = (SlopQueryNode) super.cloneTree();

    clone.value = this.value;

    return clone;
  }

  public CharSequence getField() {
    QueryNode child = getChild();

    if (child instanceof FieldableNode) {
      return ((FieldableNode) child).getField();
    }

    return null;

  }

  public void setField(CharSequence fieldName) {
    QueryNode child = getChild();

    if (child instanceof FieldableNode) {
      ((FieldableNode) child).setField(fieldName);
    }

  }

}
