package org.apache.lucene.xmlparser.builders;

import java.io.IOException;
import java.io.StringReader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.TermsFilter;
import org.apache.lucene.xmlparser.DOMUtils;
import org.apache.lucene.xmlparser.FilterBuilder;
import org.apache.lucene.xmlparser.ParserException;
import org.w3c.dom.Element;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class TermsFilterBuilder implements FilterBuilder
{
	Analyzer analyzer;
	
	/**
	 * @param analyzer
	 */
	public TermsFilterBuilder(Analyzer analyzer)
	{
		this.analyzer = analyzer;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.lucene.xmlparser.FilterBuilder#process(org.w3c.dom.Element)
	 */
	public Filter getFilter(Element e) throws ParserException
	{
		TermsFilter tf = new TermsFilter();
		String text = DOMUtils.getNonBlankTextOrFail(e);
		String fieldName = DOMUtils.getAttributeWithInheritanceOrFail(e, "fieldName");
		TokenStream ts = analyzer.tokenStream(fieldName, new StringReader(text));

		try
		{
                  final Token reusableToken = new Token();
			Term term = null;
	                for (Token nextToken = ts.next(reusableToken); nextToken != null; nextToken = ts.next(reusableToken)) {
				if (term == null)
				{
					term = new Term(fieldName, nextToken.term());
				} else
				{
//					 create from previous to save fieldName.intern overhead
					term = term.createTerm(nextToken.term()); 
				}
				tf.addTerm(term);
			}
		} 
		catch (IOException ioe)
		{
			throw new RuntimeException("Error constructing terms from index:"
					+ ioe);
		}
		return tf;
	}
}
